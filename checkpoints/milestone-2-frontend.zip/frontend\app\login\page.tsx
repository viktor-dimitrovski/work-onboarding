import { LoginForm } from '@/components/auth/login-form';

export default function LoginPage() {
  return (
    <main className='flex min-h-screen items-center justify-center px-4'>
      <div className='w-full max-w-6xl rounded-2xl border bg-white/75 p-8 shadow-soft backdrop-blur sm:p-10'>
        <div className='mb-8'>
          <p className='text-xs uppercase tracking-[0.2em] text-muted-foreground'>Internal Access</p>
          <h1 className='mt-2 text-3xl font-semibold'>Employee Onboarding Platform</h1>
          <p className='mt-2 text-sm text-muted-foreground'>
            Manage onboarding tracks, assignments, mentor approvals, and progress reporting.
          </p>
        </div>
        <LoginForm />
      </div>
    </main>
  );
}
