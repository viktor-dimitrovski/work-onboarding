from typing import Any
from uuid import UUID

from sqlalchemy.orm import Session

from app.models.audit import AuditLog


def log_action(
    db: Session,
    *,
    actor_user_id: UUID | None,
    action: str,
    entity_type: str,
    entity_id: UUID | None = None,
    status: str = 'success',
    details: dict[str, Any] | None = None,
    ip_address: str | None = None,
) -> AuditLog:
    audit = AuditLog(
        actor_user_id=actor_user_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        status=status,
        details_json=details or {},
        ip_address=ip_address,
    )
    db.add(audit)
    db.flush()
    return audit
