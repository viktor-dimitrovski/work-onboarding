-- PostgreSQL extensions needed for UUID generation.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
