# Internal Employee Onboarding Platform (MVP)

Production-minded MVP for a modular monolith onboarding platform covering role-based tracks, assignment snapshots, progress submissions, mentor approvals, and dashboard reporting.

## Stack

- Frontend: Next.js App Router, React, TypeScript, Tailwind CSS, shadcn-style UI primitives
- Forms/validation: React Hook Form + Zod
- Backend: FastAPI (Python 3.11+), SQLAlchemy 2.x, Alembic
- Database: PostgreSQL only
- Auth: JWT access + refresh with RBAC
- Tooling: Docker, docker-compose, pytest, Ruff, Black, ESLint, Prettier

## Monorepo Layout

```text
.
├─ frontend/
├─ backend/
├─ database/
│  └─ sql/
├─ docs/
├─ scripts/
├─ docker-compose.yml
├─ Makefile
└─ README.md
```

## Core Modules Implemented

- Identity and access: users, roles, user-role mapping, JWT auth/refresh/logout, `/auth/me`, password reset stub endpoint.
- Tracks: templates, versions, phases, tasks, resources, duplicate, publish.
- Assignments: assign employee to published track and generate immutable assignment snapshot.
- Progress and submissions: task submissions, mentor decisions, quiz attempts, next-task recommendation.
- Reporting: admin/HR, mentor, and employee dashboards.
- Audit logging: login success/failure, track publish, assignment creation, mentor review.

## Environment Variables

### Backend (`backend/.env`)

Required:

- `DATABASE_URL`
- `JWT_SECRET_KEY`
- `JWT_REFRESH_SECRET_KEY`
- `APP_ENV`
- `CORS_ORIGINS`
- `FIRST_ADMIN_EMAIL`
- `FIRST_ADMIN_PASSWORD`

Optional:

- `ACCESS_TOKEN_EXPIRE_MINUTES` (default `30`)
- `REFRESH_TOKEN_EXPIRE_DAYS` (default `7`)

### Frontend (`frontend/.env.local`)

- `NEXT_PUBLIC_API_BASE_URL` (default `/api/v1`)
- `BACKEND_API_URL` (used by Next rewrite, default `http://localhost:8000`)

## Replit Setup

1. Create Replit Secrets for backend:
   - `DATABASE_URL` (Replit PostgreSQL URL)
   - `JWT_SECRET_KEY`
   - `JWT_REFRESH_SECRET_KEY`
   - `APP_ENV=development`
   - `CORS_ORIGINS=https://<your-replit-domain>`
   - `FIRST_ADMIN_EMAIL`
   - `FIRST_ADMIN_PASSWORD`
2. Create frontend env file from `frontend/.env.example`.
3. Install dependencies:
   - `pip install -r backend/requirements.txt`
   - `cd frontend && npm install`
4. Run one command from repo root:
   - `python scripts/dev.py`
5. Open frontend on port `3000` (rewrites `/api/v1/*` to backend).

### Replit PostgreSQL Notes

- The app auto-uses `DATABASE_URL` when present.
- If Replit DB is missing, point `DATABASE_URL` to external PostgreSQL (Neon/Supabase/etc.).
- SQLite fallback is intentionally not implemented.

## Local Setup (Non-Docker)

1. Copy env files:
   - `cp backend/.env.example backend/.env`
   - `cp frontend/.env.example frontend/.env.local`
2. Start PostgreSQL and set `DATABASE_URL` to your DB.
3. Install dependencies:
   - `pip install -r backend/requirements.txt`
   - `cd frontend && npm install`
4. Run migrations:
   - `cd backend && alembic upgrade head`
5. Seed data:
   - `python scripts/seed_backend.py`
6. Start full stack:
   - `python scripts/dev.py`

## Docker Setup

```bash
docker compose up --build
```

Services:

- Frontend: `http://localhost:3000`
- Backend: `http://localhost:8000`
- Postgres: `localhost:5432`

## SQL Assets (`database/sql`)

- `000_extensions.sql`
- `001_local_admin_bootstrap_optional.sql`
- `010_schema.sql`
- `020_seed_reference.sql`
- `030_seed_demo.sql`
- `040_views.sql`
- `050_functions.sql`
- `900_verify.sql`
- `910_drop_dev_only.sql`

Apply manually via `psql` or use:

```bash
python scripts/seed_backend.py
```

## API Docs

- Swagger UI: `http://localhost:8000/api/v1/docs`
- OpenAPI JSON: `http://localhost:8000/api/v1/openapi.json`

## Testing

### Backend

```bash
cd backend
pytest
```

`TEST_DATABASE_URL` is required for backend tests.

### Frontend

```bash
cd frontend
npm run test
```

## Lint and Format

### Backend

```bash
cd backend
ruff check app tests
black app tests
```

### Frontend

```bash
cd frontend
npm run lint
npx prettier --write .
```

## Make Targets

- `make dev`
- `make test`
- `make lint`
- `make format`
- `make migrate`
- `make seed`
- `make reset-dev-db`
- `make docker-up`
- `make docker-down`

## Demo Seed Accounts

`030_seed_demo.sql` provisions demo users. Password for all demo users:

- `ChangeMe123!`

Emails:

- `super.admin@internal.local` (super_admin + admin)
- `admin.operations@internal.local` (admin)
- `mentor.devops@internal.local` (mentor)
- `employee.alex@internal.local` (employee)
- `employee.morgan@internal.local` (employee)
- `hr.viewer@internal.local` (hr_viewer)

## Troubleshooting

- `ModuleNotFoundError: psycopg`:
  - Install backend requirements: `pip install -r backend/requirements.txt`.
- `CORS` issues:
  - Ensure `CORS_ORIGINS` includes the frontend origin.
- 401/403 on frontend:
  - Check role assignment in `user_roles` and token expiration.
- Migration errors:
  - Verify `DATABASE_URL` points to PostgreSQL.
- Seed script failure:
  - Confirm `000_extensions.sql` executed or extension privileges allow `pgcrypto`.

## Checkpoints

Git commit checkpoints are blocked in this environment, so rollback patches were generated locally:

- `checkpoints/milestone-1-backend.patch`

You can create additional patch snapshots with:

```bash
git diff -- <path> > checkpoints/<name>.patch
```
